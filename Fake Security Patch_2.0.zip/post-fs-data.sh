#!/system/bin/sh
reset_spl="2025-09-05"
resetprop -n ro.boot.security_patch $reset_spl
resetprop -n ro.build.version.security_patch $reset_spl
resetprop -n ro.vendor.build.security_patch $reset_spl