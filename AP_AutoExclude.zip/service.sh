#!/system/bin/sh
MODDIR=${0%/*}

(
until [ $(getprop sys.boot_completed) -eq 1 ] ; do
  sleep 5
done
export PATH="/system/bin:/system/xbin:/vendor/bin:$(magisk --path)/.magisk/busybox:$PATH"
crond -c $MODDIR/cron
sleep 30
#777权限
chmod 777 /data/adb/modules/AP_AutoExclude/Whitelist520/*
rm -rf /data/adb/modules/AP_AutoExclude/update
)