#!/system/bin/sh

# 检查APatch目录
[ ! -d "/data/adb/ap" ] && {
    ui_print "错误: 当前ROOT不支持此模块！"
    ui_print "这是APatch才能用的模块，你个呆瓜"
    exit 1
}


echo "  这一纪元，我独断万古！✊"
sleep 3
am start -a android.intent.action.VIEW -d tg://resolve?domain=Whitelist520 >/dev/null 2>&1
echo " " >/data/adb/modules/AP_AutoExclude/update