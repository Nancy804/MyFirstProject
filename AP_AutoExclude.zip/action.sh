#!/bin/sh

echo ""
echo -e "                  TG频道：@Whitelist520"
sleep 1s
    echo ""
    echo "     😔红线划过深藏轮回的秘密"
    echo "     😭我挥霍运气"
    echo "     💔因为你才让我背对命运不害怕"
    
    sleep 1

sh -c /data/adb/modules/AP_AutoExclude/Whitelist520/AP_AutoExclude.sh

